﻿namespace MonkeyBuisness.Models.Filters.Movie;
public class MovieFilter
{
    public string Director { get; set; }
    public string Theme { get; set; }
    public string Name { get; set; }
    public string Grade { get; set; }
}
