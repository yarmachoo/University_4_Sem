﻿namespace MonkeyBuisness.Models.Filters.Note;
public class NoteFilter
{
    public string Subject { get; set; }
    public string Theme { get; set; }
    public string Name { get; set; }
    public string Note { get; set; }
}
