﻿using MonkeyBuisness.Models.Enum;

namespace MonkeyBuisness.Models.Filters.Task;
public class TaskFilter
{
    public string Name { get; set; }
    public Priority? Priority { get; set; }
    public DoDoingDone? DoDoingDone { get; set; }
}


