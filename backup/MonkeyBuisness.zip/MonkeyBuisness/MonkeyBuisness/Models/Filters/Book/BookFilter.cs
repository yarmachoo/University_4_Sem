﻿namespace MonkeyBuisness.Models.Filters.Book;
public class BookFilter
{
    public string Author { get; set; }
    public string Theme { get; set; }
    public string Name { get; set; }
    public string Grade { get; set; }
}
