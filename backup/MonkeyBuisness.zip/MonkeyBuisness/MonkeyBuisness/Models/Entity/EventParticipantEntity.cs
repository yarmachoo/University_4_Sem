﻿namespace MonkeyBuisness.Models.Entity;
public class EventParticipantEntity
{
    public long PersonId { get; set; }
    public PersonEntity Person { get; set; }
    public long EventId { get; set; }
    public EventEntity Event { get; set; }
}
