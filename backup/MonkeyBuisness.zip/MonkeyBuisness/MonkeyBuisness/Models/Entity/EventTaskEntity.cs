﻿using MonkeyBuisness.Models.Enum;

namespace MonkeyBuisness.Models.Entity;
public class EventTaskEntity
{
    public long Id { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public Priority Priority { get; set; }
    public DateTime Created { get; set; }
    //public DateTime Deadline { get; set; }
    public DoDoingDone DoDoingDone { get; set; }
    public long PersonId { get; set; }
    public PersonEntity Person { get; set; }   
    public long EventId { get; set; }
    public EventEntity Event { get; set; } 
}
