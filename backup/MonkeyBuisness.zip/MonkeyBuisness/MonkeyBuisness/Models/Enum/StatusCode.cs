﻿namespace MonkeyBuisness.Models.Enum;
public enum StatusCode
{
    TaskIsAlreadyExist = 1,
    OK = 200,
    InternalError = 500,
    TaskNotFound = 2
}
