﻿using System.ComponentModel.DataAnnotations;

namespace MonkeyBuisness.Models.Enum;
public enum DoDoingDone
{
    [Display(Name = "Не сделано")]
    Do = 1,
    [Display(Name = "В процессе")]
    Doing = 2,
    [Display(Name = "Сделано")]
    Done = 3
}

